
import sys
import logging

import pymysql
#rds settings
rds_host  = "skilleos-alpha-cluster.cluster-cyovo8qjujqe.eu-central-1.rds.amazonaws.com"
name = "awsuserdb"
password = "yesyoulearndb"
db_name = "skilleos"
    
logger = logging.getLogger()
logger.setLevel(logging.INFO)
try:
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    print("erreur")
    sys.exit()
    
logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")    
    

def lambda_handler(event, context):
    # TODO implement
    #connect to the rds sql database
    item_count = 0
    print("lol")

    with conn.cursor() as cur:
        cur.execute("select count(*) from yyl_user")
        for row in cur:
                item_count += 1
                logger.info(row)
                #print(row)
    conn.commit()
    
    return {
        'statusCode': 200,
        'body': json.dumps('hello world!')
    }
