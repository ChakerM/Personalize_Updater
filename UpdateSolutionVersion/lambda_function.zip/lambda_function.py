import sys
import logging
import json
import boto3


logger = logging.getLogger()


def lambda_handler(event, context):

    DataSetGroupName = "SkilleosRecommender"
    # ##### Select the dataset group
    # In[21]:
    personalize = boto3.client('personalize', region_name="eu-west-1")
    response = personalize.list_dataset_groups()
    descriptionDataset_group = personalize.describe_dataset_group(datasetGroupArn=response["datasetGroups"][0]["datasetGroupArn"])['datasetGroup']
    print("descriptionDataset_group: " + descriptionDataset_group["datasetGroupArn"])

    personalize = boto3.client('personalize', region_name="eu-west-1")
    response = personalize.list_solutions( datasetGroupArn=descriptionDataset_group["datasetGroupArn"])

    # print(response["solutions"])
    for i in range(len(response["solutions"])):
        print(response["solutions"][i]["solutionArn"])

    solution_arn = response["solutions"][1]["solutionArn"]
    solution_arn_SIMS = response["solutions"][0]["solutionArn"]

    # ## 4.2 Create solutions version
    # In[38]:
    create_solution_version_response = personalize.create_solution_version( solutionArn=solution_arn )

    solution_version_arn = create_solution_version_response['solutionVersionArn']
    print(json.dumps(create_solution_version_response, indent=2))
    create_solution_version_response_SIMS = personalize.create_solution_version( solutionArn = solution_arn_SIMS )
    solution_version_arn_SIMS = create_solution_version_response_SIMS['solutionVersionArn']
    print(json.dumps(create_solution_version_response_SIMS, indent=2))
    return {'statusCode': 200, 'body': json.dumps('hello world!')}
